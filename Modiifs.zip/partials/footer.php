<footer class="main-footer">
    <div class="footer-left">
        <a href="#"></a>
    </div>
    <div class="footer-right">
    </div>
</footer>
</div>
</div>
<!-- General JS Scripts -->
<script src="../../assets/js/app.min.js"></script>
<!-- JS Libraies -->
<!-- Page Specific JS File -->
<!-- Template JS File -->
<script src="../../assets/js/scripts.js"></script>
<!-- Custom JS File -->
<script src="../../assets/js/custom.js"></script>

<script src="../../assets/bundles/datatables/datatables.min.js"></script>
<script src="../../assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script src="../../assets/bundles/jquery-ui/jquery-ui.min.js"></script>
<!-- Page Specific JS File -->
<script src="../../assets/js/page/datatables.js"></script>
</body>


<!-- empty-state.html  21 Nov 2019 03:54:38 GMT -->

</html>